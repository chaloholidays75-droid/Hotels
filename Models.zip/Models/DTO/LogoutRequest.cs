namespace HotelAPI.Models.DTO
{
    public class LogoutRequest
    {
        public string? RefreshToken { get; set; }
    }
}