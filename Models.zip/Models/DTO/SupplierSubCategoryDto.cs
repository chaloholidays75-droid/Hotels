namespace HotelAPI.Models.DTO
{
    public class SupplierSubCategoryDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
   
    }
}
