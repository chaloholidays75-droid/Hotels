namespace HotelAPI.Models.DTO
{
    public class UpdateStatusDto
    {
        public bool IsActive { get; set; }
    }
}