namespace HotelAPI.Models.DTO
{
    public class AgencyStaffDto
    {
        public int? Id { get; set; }
        public int AgencyId { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? PhoneNo { get; set; }
        public string? Designation { get; set; }
    }

    public class AgencyStaffCreateRequest
    {
        public int AgencyId { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? PhoneNo { get; set; }
        public string? Designation { get; set; }
    }
}
